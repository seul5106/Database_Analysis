const xlsxFile = require('read-excel-file/node');

xlsxFile('./test.xlsx').then(function(rows){
    console.log(rows);
    console.log(rows[1][0]);
})